package com.example.ledremote

import android.content.Context
import android.content.res.Configuration

/** Preferencias guardadas en el celular. */
object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("ledremote", Context.MODE_PRIVATE)

    // Tema: si nunca se eligió, sigue el del sistema.
    fun isDark(c: Context): Boolean {
        val sp = p(c)
        if (sp.contains("dark")) return sp.getBoolean("dark", false)
        val night = c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return night == Configuration.UI_MODE_NIGHT_YES
    }

    fun setDark(c: Context, value: Boolean) {
        p(c).edit().putBoolean("dark", value).apply()
    }

    fun tab(c: Context): Int = p(c).getInt("tab", 0)

    fun setTab(c: Context, value: Int) {
        p(c).edit().putInt("tab", value).apply()
    }

    // Favoritos: lista de comandos de teclas.
    fun favorites(c: Context): List<Int> {
        val raw = p(c).getString("favs", "") ?: ""
        return raw.split(",").mapNotNull { it.trim().toIntOrNull() }
    }

    /** Agrega o quita un favorito. Devuelve true si quedó como favorito. */
    fun toggleFavorite(c: Context, cmd: Int): Boolean {
        val list = favorites(c).toMutableList()
        val nowFav: Boolean
        if (list.contains(cmd)) {
            list.remove(cmd)
            nowFav = false
        } else {
            list.add(cmd)
            nowFav = true
        }
        p(c).edit().putString("favs", list.joinToString(",")).apply()
        return nowFav
    }

    // Temporizador
    fun timerAt(c: Context): Long = p(c).getLong("timer_at", 0L)

    fun timerCmd(c: Context): Int = p(c).getInt("timer_cmd", Remote.CMD_OFF)

    fun setTimer(c: Context, at: Long, cmd: Int) {
        p(c).edit().putLong("timer_at", at).putInt("timer_cmd", cmd).apply()
    }

    fun clearTimer(c: Context) {
        p(c).edit().remove("timer_at").apply()
    }
}
