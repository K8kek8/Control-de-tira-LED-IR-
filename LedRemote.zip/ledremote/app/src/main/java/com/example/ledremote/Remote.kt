package com.example.ledremote

import android.graphics.Color

/** Una tecla del mando de 24 teclas. */
data class Key(
    val label: String,
    val command: Int,
    val color: Int   // color del botón en la app (ARGB)
)

object Remote {
    // Dirección NEC extendida de los mandos de 24 teclas (00 + EF).
    const val ADDR_LOW = 0x00
    const val ADDR_HIGH = 0xEF

    const val CMD_OFF = 0x02
    const val CMD_ON = 0x03

    private fun c(hex: String) = Color.parseColor(hex)

    // Comandos 0x00..0x17 en orden de lectura del mando (4 por fila).
    val keys: List<Key> = listOf(
        Key("☀ +", 0x00, c("#E0E0E0")), Key("☀ −", 0x01, c("#BDBDBD")),
        Key("OFF", 0x02, c("#212121")), Key("ON", 0x03, c("#E53935")),

        Key("R", 0x04, c("#C62828")), Key("G", 0x05, c("#2E7D32")),
        Key("B", 0x06, c("#1A237E")), Key("W", 0x07, c("#F5F5F5")),

        Key("", 0x08, c("#E53935")), Key("", 0x09, c("#43A047")),
        Key("", 0x0A, c("#1565C0")), Key("FLASH", 0x0B, c("#9E9E9E")),

        Key("", 0x0C, c("#F4511E")), Key("", 0x0D, c("#00ACC1")),
        Key("", 0x0E, c("#6A1B9A")), Key("STROBE", 0x0F, c("#9E9E9E")),

        Key("", 0x10, c("#FB8C00")), Key("", 0x11, c("#00838F")),
        Key("", 0x12, c("#8E24AA")), Key("FADE", 0x13, c("#9E9E9E")),

        Key("", 0x14, c("#FDD835")), Key("", 0x15, c("#004D60")),
        Key("", 0x16, c("#D81B60")), Key("SMOOTH", 0x17, c("#9E9E9E")),
    )

    fun byCommand(cmd: Int): Key? = keys.firstOrNull { it.command == cmd }
}
