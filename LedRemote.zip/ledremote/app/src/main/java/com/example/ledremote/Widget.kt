package com.example.ledremote

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews

/** Widget de la pantalla de inicio con los botones principales del mando. */
class LedWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        val buttons = mapOf(
            R.id.w_bplus to 0x00, R.id.w_bminus to 0x01, R.id.w_off to 0x02, R.id.w_on to 0x03,
            R.id.w_r to 0x04, R.id.w_g to 0x05, R.id.w_b to 0x06, R.id.w_w to 0x07
        )
        for (id in appWidgetIds) {
            val views = RemoteViews(context.packageName, R.layout.widget_led)
            for ((viewId, cmd) in buttons) {
                views.setOnClickPendingIntent(viewId, IrActionReceiver.pending(context, cmd))
            }
            appWidgetManager.updateAppWidget(id, views)
        }
    }
}

/** Recibe los toques del widget y manda la señal IR. */
class IrActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val cmd = intent.getIntExtra("cmd", -1)
        if (cmd < 0) return
        IrSender.buzz(context)
        IrSender.send(context, cmd)
    }

    companion object {
        const val ACTION = "com.example.ledremote.SEND_IR"

        fun pending(context: Context, cmd: Int): PendingIntent {
            val i = Intent(context, IrActionReceiver::class.java).apply {
                action = ACTION
                putExtra("cmd", cmd)
                data = Uri.parse("ledremote://cmd/$cmd")
            }
            return PendingIntent.getBroadcast(
                context, cmd, i,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
    }
}
