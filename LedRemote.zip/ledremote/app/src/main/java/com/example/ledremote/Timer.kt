package com.example.ledremote

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Programa y cancela el temporizador de encendido/apagado. */
object TimerScheduler {

    private fun pending(c: Context, cmd: Int): PendingIntent {
        val i = Intent(c, TimerReceiver::class.java).putExtra("cmd", cmd)
        return PendingIntent.getBroadcast(
            c, 7001, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(c: Context, minutes: Int, cmd: Int) {
        val at = System.currentTimeMillis() + minutes * 60_000L
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(c, cmd)
        try {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
        Prefs.setTimer(c, at, cmd)
    }

    fun cancel(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(c, Remote.CMD_OFF))
        Prefs.clearTimer(c)
    }
}

/** Se ejecuta cuando vence el temporizador y manda ON u OFF a la tira. */
class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val cmd = intent.getIntExtra("cmd", Remote.CMD_OFF)
        IrSender.send(context, cmd)
        IrSender.buzz(context)
        Prefs.clearTimer(context)
    }
}
