package com.example.ledremote

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.ConsumerIrManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private var ir: ConsumerIrManager? = null

    /** Botón del mando de 24 teclas: etiqueta, comando NEC y color de fondo. */
    private data class Key(val label: String, val command: Int, val color: Int)

    // Dirección NEC extendida de los mandos de 24 teclas (00 + EF).
    private val addrLow = 0x00
    private val addrHigh = 0xEF

    // Comandos 0x00..0x17 en orden de lectura del mando (4 por fila).
    private val keys = listOf(
        Key("☀ +", 0x00, 0xFFE0E0E0.toInt()), Key("☀ −", 0x01, 0xFFBDBDBD.toInt()),
        Key("OFF", 0x02, 0xFF212121.toInt()), Key("ON", 0x03, 0xFFE53935.toInt()),

        Key("R", 0x04, 0xFFC62828.toInt()), Key("G", 0x05, 0xFF2E7D32.toInt()),
        Key("B", 0x06, 0xFF1A237E.toInt()), Key("W", 0x07, 0xFFF5F5F5.toInt()),

        Key("", 0x08, 0xFFE53935.toInt()), Key("", 0x09, 0xFF43A047.toInt()),
        Key("", 0x0A, 0xFF1565C0.toInt()), Key("FLASH", 0x0B, 0xFF9E9E9E.toInt()),

        Key("", 0x0C, 0xFFF4511E.toInt()), Key("", 0x0D, 0xFF00ACC1.toInt()),
        Key("", 0x0E, 0xFF6A1B9A.toInt()), Key("STROBE", 0x0F, 0xFF9E9E9E.toInt()),

        Key("", 0x10, 0xFFFB8C00.toInt()), Key("", 0x11, 0xFF00838F.toInt()),
        Key("", 0x12, 0xFF8E24AA.toInt()), Key("FADE", 0x13, 0xFF9E9E9E.toInt()),

        Key("", 0x14, 0xFFFDD835.toInt()), Key("", 0x15, 0xFF004D60.toInt()),
        Key("", 0x16, 0xFFD81B60.toInt()), Key("SMOOTH", 0x17, 0xFF9E9E9E.toInt()),
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ir = getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }

        root.addView(TextView(this).apply {
            text = "LED Remote"
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
        })

        val status = TextView(this).apply {
            textSize = 13f
            setPadding(0, dp(4), 0, dp(12))
            text = if (ir?.hasIrEmitter() == true) {
                "Emisor IR detectado. Apunta el celular a la tira."
            } else {
                "Este celular NO tiene emisor infrarrojo, la app no podrá enviar señales."
            }
        }
        root.addView(status)

        // Cuadrícula de 4 columnas
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        keys.chunked(4).forEach { rowKeys ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowKeys.forEach { row.addView(makeButton(it)) }
            grid.addView(row)
        }
        root.addView(grid)

        // Código personalizado
        root.addView(TextView(this).apply {
            text = "Código personalizado (hexadecimal)"
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(20), 0, dp(4))
        })
        val lowInput = EditText(this).apply {
            hint = "Dirección byte bajo (ej. 00)"
            setText("00")
        }
        val highInput = EditText(this).apply {
            hint = "Dirección byte alto (ej. EF)"
            setText("EF")
        }
        val cmdInput = EditText(this).apply {
            hint = "Comando (ej. 03)"
        }
        val sendBtn = Button(this).apply {
            text = "Enviar"
            setOnClickListener {
                val lo = lowInput.text.toString().trim().toIntOrNull(16)
                val hi = highInput.text.toString().trim().toIntOrNull(16)
                val c = cmdInput.text.toString().trim().toIntOrNull(16)
                if (lo == null || hi == null || c == null ||
                    lo !in 0..255 || hi !in 0..255 || c !in 0..255
                ) {
                    toast("Usa valores hexadecimales de 00 a FF")
                } else {
                    send(lo, hi, c)
                }
            }
        }
        root.addView(lowInput)
        root.addView(highInput)
        root.addView(cmdInput)
        root.addView(sendBtn)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun makeButton(key: Key): View {
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(key.color)
            setStroke(dp(1), 0x33000000)
        }
        val lum = (0.299 * Color.red(key.color) + 0.587 * Color.green(key.color) +
            0.114 * Color.blue(key.color)) / 255.0
        val darkBg = lum < 0.5
        return Button(this).apply {
            text = key.label
            textSize = 11f
            background = bg
            setTextColor(if (darkBg) Color.WHITE else Color.BLACK)
            layoutParams = LinearLayout.LayoutParams(0, dp(72), 1f).apply {
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            gravity = Gravity.CENTER
            setOnClickListener { send(addrLow, addrHigh, key.command) }
        }
    }

    /** Vibración corta para confirmar que se tocó una tecla. */
    @Suppress("DEPRECATION")
    private fun buzz() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (!v.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= 26) {
            v.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            v.vibrate(35)
        }
    }

    private fun send(lo: Int, hi: Int, cmd: Int) {
        buzz()
        val manager = ir
        if (manager == null || !manager.hasIrEmitter()) {
            toast("Este celular no tiene emisor infrarrojo")
            return
        }
        manager.transmit(Nec.CARRIER_HZ, Nec.pattern(lo, hi, cmd))
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
