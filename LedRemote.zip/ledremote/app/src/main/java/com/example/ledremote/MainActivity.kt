package com.example.ledremote

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private var ir: ConsumerIrManager? = null

    /** Botón del mando de 24 teclas: etiqueta, comando NEC y color de fondo. */
    private data class Key(val label: String, val command: Int, val color: Int)

    // Dirección NEC habitual de los mandos de 24 teclas.
    private val address = 0x00

    // Códigos más comunes del mando de 24 teclas. Si alguno no responde en tu tira,
    // usa la sección "Código personalizado" para probar otros.
    private val keys = listOf(
        Key("☀ +", 0x5C, 0xFFE0E0E0.toInt()), Key("☀ −", 0x5D, 0xFFBDBDBD.toInt()),
        Key("OFF", 0x41, 0xFF424242.toInt()), Key("ON", 0x40, 0xFFFFFFFF.toInt()),

        Key("R", 0x58, 0xFFE53935.toInt()), Key("G", 0x59, 0xFF43A047.toInt()),
        Key("B", 0x45, 0xFF1E88E5.toInt()), Key("W", 0x44, 0xFFF5F5F5.toInt()),

        Key("", 0x54, 0xFFFF7043.toInt()), Key("", 0x55, 0xFF66BB6A.toInt()),
        Key("", 0x49, 0xFF42A5F5.toInt()), Key("FLASH", 0x48, 0xFFE0E0E0.toInt()),

        Key("", 0x50, 0xFFFFA726.toInt()), Key("", 0x51, 0xFF26C6DA.toInt()),
        Key("", 0x4D, 0xFF7E57C2.toInt()), Key("STROBE", 0x4C, 0xFFE0E0E0.toInt()),

        Key("", 0x1C, 0xFFFDD835.toInt()), Key("", 0x1D, 0xFF26A69A.toInt()),
        Key("", 0x1E, 0xFFEC407A.toInt()), Key("FADE", 0x1F, 0xFFE0E0E0.toInt()),

        Key("", 0x18, 0xFFFFEE58.toInt()), Key("", 0x19, 0xFF00ACC1.toInt()),
        Key("", 0x1A, 0xFFAB47BC.toInt()), Key("SMOOTH", 0x1B, 0xFFE0E0E0.toInt()),
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ir = getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }

        root.addView(TextView(this).apply {
            text = "LED Remote"
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
        })

        val status = TextView(this).apply {
            textSize = 13f
            setPadding(0, dp(4), 0, dp(12))
            text = if (ir?.hasIrEmitter() == true) {
                "Emisor IR detectado. Apunta el celular a la tira."
            } else {
                "Este celular NO tiene emisor infrarrojo, la app no podrá enviar señales."
            }
        }
        root.addView(status)

        // Cuadrícula de 4 columnas
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        keys.chunked(4).forEach { rowKeys ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowKeys.forEach { row.addView(makeButton(it)) }
            grid.addView(row)
        }
        root.addView(grid)

        // Código personalizado
        root.addView(TextView(this).apply {
            text = "Código personalizado (hexadecimal)"
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(20), 0, dp(4))
        })
        val addrInput = EditText(this).apply {
            hint = "Dirección (ej. 00)"
            setText("00")
        }
        val cmdInput = EditText(this).apply {
            hint = "Comando (ej. 40)"
        }
        val sendBtn = Button(this).apply {
            text = "Enviar"
            setOnClickListener {
                val a = addrInput.text.toString().trim().toIntOrNull(16)
                val c = cmdInput.text.toString().trim().toIntOrNull(16)
                if (a == null || c == null || a !in 0..255 || c !in 0..255) {
                    toast("Usa valores hexadecimales de 00 a FF")
                } else {
                    send(a, c)
                }
            }
        }
        root.addView(addrInput)
        root.addView(cmdInput)
        root.addView(sendBtn)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun makeButton(key: Key): View {
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(key.color)
            setStroke(dp(1), 0x33000000)
        }
        val lum = (0.299 * Color.red(key.color) + 0.587 * Color.green(key.color) +
            0.114 * Color.blue(key.color)) / 255.0
        val darkBg = lum < 0.5
        return Button(this).apply {
            text = key.label
            textSize = 11f
            background = bg
            setTextColor(if (darkBg) Color.WHITE else Color.BLACK)
            layoutParams = LinearLayout.LayoutParams(0, dp(72), 1f).apply {
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            gravity = Gravity.CENTER
            setOnClickListener { send(address, key.command) }
        }
    }

    private fun send(addr: Int, cmd: Int) {
        val manager = ir
        if (manager == null || !manager.hasIrEmitter()) {
            toast("Este celular no tiene emisor infrarrojo")
            return
        }
        manager.transmit(Nec.CARRIER_HZ, Nec.pattern(addr, cmd))
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
