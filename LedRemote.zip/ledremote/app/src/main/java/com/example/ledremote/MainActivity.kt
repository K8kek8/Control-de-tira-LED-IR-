package com.example.ledremote

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Space
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Colores de la interfaz para cada tema. */
private class Pal(
    val bg: Int,
    val surface: Int,
    val text: Int,
    val sub: Int,
    val accent: Int,
    val onAccent: Int
)

class MainActivity : Activity() {

    private val lightPal = Pal(
        Color.parseColor("#F5F5F5"), Color.WHITE, Color.parseColor("#212121"),
        Color.parseColor("#616161"), Color.parseColor("#3949AB"), Color.WHITE
    )
    private val darkPal = Pal(
        Color.parseColor("#121212"), Color.parseColor("#1E1E1E"), Color.parseColor("#EEEEEE"),
        Color.parseColor("#AAAAAA"), Color.parseColor("#9FA8DA"), Color.parseColor("#121212")
    )

    private lateinit var pal: Pal
    private var dark = false
    private var tab = 0
    private var timerCmd = Remote.CMD_OFF

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tab = Prefs.tab(this).coerceIn(0, 2)
        buildUi()
    }

    // ───────────────────────── Estructura general ─────────────────────────

    private fun buildUi() {
        dark = Prefs.isDark(this)
        pal = if (dark) darkPal else lightPal
        applySystemBars()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pal.bg)
        }
        root.addView(buildHeader())

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        scroll.addView(
            when (tab) {
                0 -> buildControlTab()
                1 -> buildFavoritesTab()
                else -> buildTimerTab()
            }
        )
        root.addView(scroll)
        root.addView(buildTabBar())
        setContentView(root)
    }

    @Suppress("DEPRECATION")
    private fun applySystemBars() {
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.surface
        var flags = window.decorView.systemUiVisibility
        if (Build.VERSION.SDK_INT >= 23) {
            flags = if (dark) {
                flags and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            } else {
                flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            }
        }
        if (Build.VERSION.SDK_INT >= 26) {
            flags = if (dark) {
                flags and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
            } else {
                flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
        }
        window.decorView.systemUiVisibility = flags
    }

    private fun buildHeader(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(8))
        }
        row.addView(TextView(this).apply {
            text = "LED Remote"
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(pal.text)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        row.addView(TextView(this).apply {
            text = if (dark) "Tema oscuro" else "Tema claro"
            textSize = 12f
            setTextColor(pal.sub)
            setPadding(0, 0, dp(8), 0)
        })
        row.addView(Switch(this).apply {
            isChecked = dark
            setOnCheckedChangeListener { _, checked ->
                Prefs.setDark(this@MainActivity, checked)
                buildUi()
            }
        })
        return row
    }

    private fun buildTabBar(): View {
        val names = listOf("Mando", "Favoritos", "Timer")
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(pal.surface)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        names.forEachIndexed { i, name ->
            val selected = i == tab
            bar.addView(TextView(this).apply {
                text = name
                gravity = Gravity.CENTER
                textSize = 14f
                setPadding(0, dp(10), 0, dp(10))
                setTextColor(if (selected) pal.onAccent else pal.text)
                if (selected) setTypeface(typeface, Typeface.BOLD)
                background = GradientDrawable().apply {
                    cornerRadius = dp(20).toFloat()
                    setColor(if (selected) pal.accent else Color.TRANSPARENT)
                }
                layoutParams =
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        setMargins(dp(3), 0, dp(3), 0)
                    }
                setOnClickListener {
                    if (tab != i) {
                        tab = i
                        Prefs.setTab(this@MainActivity, i)
                        buildUi()
                    }
                }
            })
        }
        return bar
    }

    // ───────────────────────── Pestaña 1: Mando ─────────────────────────

    private fun buildControlTab(): View {
        val col = column()
        col.addView(
            tv(
                if (IrSender.hasEmitter(this)) {
                    "Emisor IR detectado. Apunta el celular a la tira."
                } else {
                    "Este celular NO tiene emisor infrarrojo, la app no podrá enviar señales."
                },
                13f, pal.sub
            )
        )
        col.addView(tv("Mantén presionada una tecla para guardarla en ★ Favoritos.", 12f, pal.sub))

        Remote.keys.chunked(4).forEach { group ->
            val r = row()
            group.forEach { key ->
                r.addView(makeKeyButton(key) { btn ->
                    val nowFav = Prefs.toggleFavorite(this, key.command)
                    btn.text = keyLabel(key)
                    IrSender.buzz(this)
                    toast(if (nowFav) "Agregado a favoritos" else "Quitado de favoritos")
                })
            }
            col.addView(r)
        }

        // Código personalizado (útil para probar otros comandos)
        col.addView(
            tv("Código personalizado (hexadecimal)", 14f, bold = true).apply {
                setPadding(0, dp(20), 0, dp(4))
            }
        )
        val lowInput = input("Dirección byte bajo (ej. 00)", "00")
        val highInput = input("Dirección byte alto (ej. EF)", "EF")
        val cmdInput = input("Comando (ej. 03)")
        col.addView(lowInput)
        col.addView(highInput)
        col.addView(cmdInput)
        col.addView(actionButton("Enviar") {
            val lo = lowInput.text.toString().trim().toIntOrNull(16)
            val hi = highInput.text.toString().trim().toIntOrNull(16)
            val c = cmdInput.text.toString().trim().toIntOrNull(16)
            if (lo == null || hi == null || c == null ||
                lo !in 0..255 || hi !in 0..255 || c !in 0..255
            ) {
                toast("Usa valores hexadecimales de 00 a FF")
            } else {
                IrSender.buzz(this)
                if (!IrSender.send(this, c, lo, hi)) {
                    toast("Este celular no tiene emisor infrarrojo")
                }
            }
        })
        return col
    }

    // ───────────────────────── Pestaña 2: Favoritos ─────────────────────────

    private fun buildFavoritesTab(): View {
        val col = column()
        col.addView(tv("Favoritos", 18f, bold = true))

        val favs = Prefs.favorites(this).mapNotNull { Remote.byCommand(it) }
        if (favs.isEmpty()) {
            col.addView(
                tv(
                    "Aún no tienes favoritos. En la pestaña Mando mantén presionada " +
                        "una tecla para guardarla aquí.",
                    13f, pal.sub
                )
            )
        } else {
            col.addView(tv("Toca para enviar. Mantén presionada una tecla para quitarla.", 12f, pal.sub))
            favs.chunked(4).forEach { group ->
                val r = row()
                group.forEach { key ->
                    r.addView(makeKeyButton(key) { _ ->
                        Prefs.toggleFavorite(this, key.command)
                        IrSender.buzz(this)
                        buildUi()
                    })
                }
                repeat(4 - group.size) {
                    r.addView(Space(this).apply {
                        layoutParams = LinearLayout.LayoutParams(0, dp(72), 1f)
                    })
                }
                col.addView(r)
            }
        }
        return col
    }

    // ───────────────────────── Pestaña 3: Temporizador ─────────────────────────

    private fun buildTimerTab(): View {
        val col = column()
        col.addView(tv("Temporizador", 18f, bold = true))
        col.addView(
            tv(
                "Programa que la tira se apague o se encienda dentro de un tiempo. " +
                    "Funciona aunque cierres la app.",
                12f, pal.sub
            )
        )

        // Apagar / Encender
        val modeRow = row()
        val offBtn = pill("Apagar")
        val onBtn = pill("Encender")
        fun refreshMode() {
            stylePill(offBtn, timerCmd == Remote.CMD_OFF)
            stylePill(onBtn, timerCmd == Remote.CMD_ON)
        }
        offBtn.setOnClickListener {
            timerCmd = Remote.CMD_OFF
            refreshMode()
        }
        onBtn.setOnClickListener {
            timerCmd = Remote.CMD_ON
            refreshMode()
        }
        refreshMode()
        modeRow.addView(offBtn)
        modeRow.addView(onBtn)
        col.addView(modeRow)

        // Minutos
        col.addView(tv("¿En cuántos minutos?", 14f, bold = true).apply {
            setPadding(0, dp(16), 0, dp(4))
        })
        val minutes = input("Minutos", "30", numeric = true)
        col.addView(minutes)

        val presets = row()
        listOf(15, 30, 60, 120).forEach { m ->
            val b = pill("$m min")
            stylePill(b, false)
            b.setOnClickListener { minutes.setText(m.toString()) }
            presets.addView(b)
        }
        col.addView(presets)

        // Estado
        val status = tv("", 13f, pal.sub).apply { setPadding(0, dp(12), 0, dp(4)) }
        fun refreshStatus() {
            val at = Prefs.timerAt(this)
            if (at > System.currentTimeMillis()) {
                val what = if (Prefs.timerCmd(this) == Remote.CMD_OFF) "apagar" else "encender"
                val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(at))
                status.text = "Programado: $what a las $time"
            } else {
                status.text = "Sin temporizador activo"
            }
        }
        refreshStatus()
        col.addView(status)

        col.addView(actionButton("Iniciar temporizador") {
            val m = minutes.text.toString().trim().toIntOrNull()
            if (m == null || m < 1 || m > 1440) {
                toast("Escribe entre 1 y 1440 minutos")
            } else {
                TimerScheduler.schedule(this, m, timerCmd)
                IrSender.buzz(this)
                refreshStatus()
            }
        })
        col.addView(actionButton("Cancelar temporizador", filled = false) {
            TimerScheduler.cancel(this)
            IrSender.buzz(this)
            refreshStatus()
        })
        col.addView(
            tv("Si reinicias el celular, el temporizador se cancela.", 12f, pal.sub)
        )
        return col
    }

    // ───────────────────────── Componentes ─────────────────────────

    private fun keyLabel(key: Key): String {
        val fav = Prefs.favorites(this).contains(key.command)
        return (key.label + if (fav) " ★" else "").trim()
    }

    private fun makeKeyButton(key: Key, longPress: ((Button) -> Unit)? = null): View {
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(key.color)
            setStroke(dp(1), 0x33000000)
        }
        val lum = (0.299 * Color.red(key.color) + 0.587 * Color.green(key.color) +
            0.114 * Color.blue(key.color)) / 255.0
        return Button(this).apply {
            text = keyLabel(key)
            textSize = 11f
            background = bg
            setTextColor(if (lum < 0.5) Color.WHITE else Color.BLACK)
            layoutParams = LinearLayout.LayoutParams(0, dp(72), 1f).apply {
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            gravity = Gravity.CENTER
            setOnClickListener { tap(key.command) }
            if (longPress != null) {
                setOnLongClickListener {
                    longPress(this)
                    true
                }
            }
        }
    }

    private fun tap(cmd: Int) {
        IrSender.buzz(this)
        if (!IrSender.send(this, cmd)) {
            toast("Este celular no tiene emisor infrarrojo")
        }
    }

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(8), dp(16), dp(16))
    }

    private fun row() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun tv(t: String, size: Float = 14f, color: Int = pal.text, bold: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(4), 0, dp(4))
        }

    private fun input(hintText: String, initial: String = "", numeric: Boolean = false) =
        EditText(this).apply {
            hint = hintText
            setText(initial)
            setTextColor(pal.text)
            setHintTextColor(pal.sub)
            backgroundTintList = ColorStateList.valueOf(pal.sub)
            if (numeric) inputType = InputType.TYPE_CLASS_NUMBER
        }

    private fun actionButton(title: String, filled: Boolean = true, onClick: () -> Unit) =
        Button(this).apply {
            text = title
            setAllCaps(false)
            setTextColor(if (filled) pal.onAccent else pal.text)
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(if (filled) pal.accent else pal.surface)
                if (!filled) setStroke(dp(1), pal.sub)
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, dp(6), 0, dp(6)) }
            setOnClickListener { onClick() }
        }

    private fun pill(title: String) = Button(this).apply {
        text = title
        setAllCaps(false)
        textSize = 13f
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dp(3), dp(4), dp(3), dp(4))
        }
        stylePill(this, false)
    }

    private fun stylePill(b: Button, selected: Boolean) {
        b.setTextColor(if (selected) pal.onAccent else pal.text)
        b.background = GradientDrawable().apply {
            cornerRadius = dp(22).toFloat()
            setColor(if (selected) pal.accent else pal.surface)
            setStroke(dp(1), if (selected) pal.accent else pal.sub)
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
