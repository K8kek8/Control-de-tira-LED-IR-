package com.example.ledremote

/**
 * Codificador del protocolo NEC (el que usan casi todos los controles de tiras LED chinas).
 * Devuelve el patrón alternado encendido/apagado en microsegundos, que es lo que
 * espera ConsumerIrManager.transmit().
 */
object Nec {
    const val CARRIER_HZ = 38000

    private const val HEADER_MARK = 9000
    private const val HEADER_SPACE = 4500
    private const val BIT_MARK = 560
    private const val ZERO_SPACE = 560
    private const val ONE_SPACE = 1690

    /** Trama NEC: dirección, ~dirección, comando, ~comando (bit menos significativo primero). */
    fun pattern(address: Int, command: Int): IntArray {
        val a = address and 0xFF
        val c = command and 0xFF
        val data = a or ((a.inv() and 0xFF) shl 8) or (c shl 16) or ((c.inv() and 0xFF) shl 24)

        val out = ArrayList<Int>(68)
        out.add(HEADER_MARK)
        out.add(HEADER_SPACE)
        for (i in 0 until 32) {
            out.add(BIT_MARK)
            out.add(if ((data shr i) and 1 == 1) ONE_SPACE else ZERO_SPACE)
        }
        out.add(BIT_MARK) // marca final
        return out.toIntArray()
    }
}
