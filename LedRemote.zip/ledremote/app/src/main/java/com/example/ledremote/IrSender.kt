package com.example.ledremote

import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator

/** Envío de señales IR y vibración, usable desde la app, el widget y el temporizador. */
object IrSender {

    fun hasEmitter(context: Context): Boolean {
        val m = context.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        return m?.hasIrEmitter() == true
    }

    /** Envía un comando del mando. Devuelve false si el celular no tiene emisor IR. */
    fun send(
        context: Context,
        cmd: Int,
        lo: Int = Remote.ADDR_LOW,
        hi: Int = Remote.ADDR_HIGH
    ): Boolean {
        val m = context.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
            ?: return false
        if (!m.hasIrEmitter()) return false
        m.transmit(Nec.CARRIER_HZ, Nec.pattern(lo, hi, cmd))
        return true
    }

    /** Vibración corta de confirmación. */
    @Suppress("DEPRECATION")
    fun buzz(context: Context) {
        val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (!v.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= 26) {
            v.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            v.vibrate(35)
        }
    }
}
